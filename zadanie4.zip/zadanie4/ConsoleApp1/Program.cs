﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine();

        bool isValid = CheckIfValid(input);

        if (!isValid)
        {
            Console.WriteLine("Ошибка! В строке введены неподходящие символы.");

            // выводим список неподходящих символов
            Console.Write("Неподходящие символы: ");
            foreach (char c in input)
            {
                if (!Char.IsLower(c) || !Char.IsLetter(c)) // проверяем, является ли символ буквой в нижнем регистре
                {
                    Console.Write(c + " ");
                }
            }

            Console.WriteLine();
        }
        else // если введенная строка подходит
        {
            string result = "";

            if (input.Length % 2 == 0) // если строка четная
            {
                int mid = input.Length / 2;
                string firstHalf = input.Substring(0, mid);
                string secondHalf = input.Substring(mid);

                string reversedFirstHalf = ReverseString(firstHalf);
                string reversedSecondHalf = ReverseString(secondHalf);

                result = reversedFirstHalf + reversedSecondHalf;
            }
            else // если строка нечетная
            {
                string reversedInput = ReverseString(input);
                result = reversedInput + input;
            }

            Console.WriteLine($"Обработанная строка: {result}");

            // подсчитываем количество повторений каждого символа
            Dictionary<char, int> charCount = new Dictionary<char, int>();
            foreach (char c in result)
            {
                if (charCount.ContainsKey(c))
                {
                    charCount[c]++;
                }
                else
                {
                    charCount[c] = 1;
                }
            }

            // выводим информацию о количестве повторений каждого символа
            Console.WriteLine("Количество повторений каждого символа:");
            foreach (KeyValuePair<char, int> pair in charCount)
            {
                Console.WriteLine($"Символ {pair.Key}: {pair.Value} раз(а)");
            }

            // ищем самую длинную подстроку, начинающуюся и заканчивающуюся на гласные
            string longestVowelSubstring = "";
            string currentVowelSubstring = "";
            for (int i = 0; i < result.Length; i++)
            {
                char c = result[i];
                if ("aeiouy".Contains(c))
                {
                    currentVowelSubstring += c;
                }
                else
                {
                    if (currentVowelSubstring.Length > 0 && currentVowelSubstring[currentVowelSubstring.Length - 1] != ' ')
                    {
                        if (currentVowelSubstring.Length > longestVowelSubstring.Length)
                        {
                            longestVowelSubstring = currentVowelSubstring;
                        }
                        currentVowelSubstring = "";
                    }
                }
            }
            if (currentVowelSubstring.Length > 0 && currentVowelSubstring[currentVowelSubstring.Length - 1] != ' ')
            {
                if (currentVowelSubstring.Length > longestVowelSubstring.Length)
                {
                    longestVowelSubstring = currentVowelSubstring;
                }
            }

            if (longestVowelSubstring.Length > 0)
            {

                ChatGPT, [6 / 11 / 2023 7:00 PM]
Console.WriteLine($"Самая длинная подстрока, начинающаяся и заканчивающаяся на гласную: {longestVowelSubstring}");
            }
            else
            {
                Console.WriteLine("В обработанной строке нет подстрок, начинающихся и заканчивающихся на гласную букву");
            }
        }
    }

    static string ReverseString(string str)
    {
        char[] charArray = str.ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }

    static bool CheckIfValid(string str)
    {
        foreach (char c in str)
        {
            if (!Char.IsLower(c) || !Char.IsLetter(c)) // проверяем, является ли символ буквой в нижнем регистре
            {
                return false; // если есть неподходящий символ, возвращаем false
            }
        }

        return true; // если все символы подходят, возвращаем true
    }
}
